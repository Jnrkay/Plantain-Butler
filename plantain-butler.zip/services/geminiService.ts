import { GoogleGenAI, Type } from "@google/genai";
import { TrackedItem, Budget, MonthlyBudget, Category, BudgetRecommendation } from "../types";
import { CATEGORIES } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const receiptSchema = {
    type: Type.OBJECT,
    properties: {
        items: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING, description: "The name of the grocery item." },
                    quantity: { type: Type.NUMBER, description: "The quantity of the item purchased." },
                    unitPrice: { type: Type.NUMBER, description: "The price per unit of the item. Do not include currency symbols." },
                    totalPrice: { type: Type.NUMBER, description: "The total price for this line item (quantity * unitPrice). Do not include currency symbols." },
                    category: {
                        type: Type.STRING,
                        enum: CATEGORIES,
                        description: "The most appropriate category for the item."
                    },
                    lowStockThreshold: {
                        type: Type.NUMBER,
                        description: "A sensible default for when this item should be considered low stock. For single items like a whole chicken, this should be 1. For items in packs, it could be higher. Default to 1 if unsure."
                    },
                    estimatedFinishDate: {
                        type: Type.STRING,
                        description: "An estimated date in YYYY-MM-DD format when this item will be fully consumed, based on typical household usage. Be realistic. For example, milk might last a week, bread a few days, a large bag of rice a month."
                    }
                },
                required: ["name", "quantity", "totalPrice", "category", "lowStockThreshold"]
            }
        }
    },
    required: ["items"]
};

export async function parseReceipt(
  base64Image: string,
  mimeType: string
): Promise<Omit<TrackedItem, 'id'>[]> {
  if (!process.env.API_KEY) {
    throw new Error("API key not configured.");
  }

  const imagePart = {
    inlineData: {
      mimeType,
      data: base64Image,
    },
  };

  const textPart = {
    text: `You are an expert receipt processing system for a grocery intelligence app. Extract all items from this receipt.
    For each item, provide its name, quantity, unit price (if available, otherwise calculate it), total price, category, a sensible low stock threshold, and an estimated finish date.
    The finish date should be a realistic estimate of when the item will be consumed based on its type and quantity.
    The currency is Ghanaian Cedis (GHS), but do not include the currency symbol or name in the price fields. The receipt is from Ghana.
    Use only the following categories: ${CATEGORIES.join(', ')}.
    Provide the output in the specified JSON format.`
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: receiptSchema,
      }
    });
    
    const jsonString = response.text.trim();
    const cleanedJsonString = jsonString.replace(/^```json\s*|```$/g, '');
    const parsed = JSON.parse(cleanedJsonString);

    if (parsed && Array.isArray(parsed.items)) {
        return parsed.items.map((item: any) => ({
            name: item.name,
            category: item.category || 'Other',
            quantity: item.quantity || 1,
            initialQuantity: item.quantity || 1,
            unitPrice: item.unitPrice || item.totalPrice / (item.quantity || 1),
            totalPrice: item.totalPrice,
            lowStockThreshold: item.lowStockThreshold || 1,
            purchaseDate: new Date().toISOString(),
            estimatedFinishDate: item.estimatedFinishDate ? new Date(item.estimatedFinishDate).toISOString() : undefined,
        }));
    }
    return [];
  } catch (error) {
    console.error("Error parsing receipt with Gemini API:", error);
    throw new Error("Could not understand the receipt. Please try a clearer picture.");
  }
}

export async function parseStructuredData(
  dataContent: string
): Promise<Omit<TrackedItem, 'id'>[]> {
  if (!process.env.API_KEY) {
    throw new Error("API key not configured.");
  }

  const textPart = {
    text: `You are an expert data processing system for a grocery intelligence app. Extract all grocery items from the following text. The text could be a simple list, a multi-line document, comma-separated values (CSV), or data extracted from a PDF or Excel sheet. Ignore any headers or irrelevant text and focus on the item data.
    For each item, provide its name, quantity, unit price (if available, otherwise calculate it), total price, category, a sensible low stock threshold, and an estimated finish date.
    The finish date should be a realistic estimate of when the item will be consumed based on its type and quantity.
    The currency is likely Ghanaian Cedis (GHS), but do not include the currency symbol or name in the price fields.
    Use only the following categories: ${CATEGORIES.join(', ')}.
    Provide the output in the specified JSON format.

    Data content to parse:
    ---
    ${dataContent}
    ---`
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: receiptSchema,
      }
    });
    
    const jsonString = response.text.trim();
    const cleanedJsonString = jsonString.replace(/^```json\s*|```$/g, '');
    const parsed = JSON.parse(cleanedJsonString);

    if (parsed && Array.isArray(parsed.items)) {
        return parsed.items.map((item: any) => ({
            name: item.name,
            category: item.category || 'Other',
            quantity: item.quantity || 1,
            initialQuantity: item.quantity || 1,
            unitPrice: item.unitPrice || item.totalPrice / (item.quantity || 1),
            totalPrice: item.totalPrice,
            lowStockThreshold: item.lowStockThreshold || 1,
            purchaseDate: new Date().toISOString(),
            estimatedFinishDate: item.estimatedFinishDate ? new Date(item.estimatedFinishDate).toISOString() : undefined,
        }));
    }
    return [];
  } catch (error) {
    console.error("Error parsing text content with Gemini API:", error);
    throw new Error("Could not understand the document content. Please check the format.");
  }
}


export async function getAssistantResponse(
  inventory: TrackedItem[],
  budgets: Budget,
  question: string
): Promise<string> {
  if (!process.env.API_KEY) {
    return "API key not configured.";
  }
  
  if (inventory.length === 0) {
      return "I have no data to analyze. Please add an item to your inventory first.";
  }

  const currentMonthKey = new Date().toISOString().slice(0, 7); // "YYYY-MM"
  const currentBudget: MonthlyBudget | undefined = budgets[currentMonthKey];

  const formattedInventory = inventory
    .map(item => `Item: ${item.name}, Current Quantity: ${item.quantity}, Category: ${item.category}, Unit Price: ${item.unitPrice.toFixed(2)} GHS, Total Price: ${item.totalPrice.toFixed(2)} GHS, Purchased On: ${new Date(item.purchaseDate).toLocaleDateString()}.`)
    .join('\n');

  let budgetInfo = `There is no budget set for the current month.`;
  if (currentBudget) {
      const categoryBudgets = Object.entries(currentBudget.categories)
        .map(([cat, amount]) => `${cat}: ${amount.toFixed(2)} GHS`)
        .join(', ');
      
      budgetInfo = `The total budget for the current month (${currentMonthKey}) is ${currentBudget.total.toFixed(2)} GHS.`;
      if (categoryBudgets) {
          budgetInfo += `\nSpecific category budgets are: ${categoryBudgets}.`;
      }
  }

  const prompt = `You are a helpful grocery intelligence assistant. Your knowledge is strictly limited to the user's current inventory and budget. Answer the user's questions based only on this data.
You can answer questions about:
- Current stock levels (how much is left).
- Purchase history and spending habits.
- Price changes for specific items over time (by comparing 'Unit Price' for items with the same name across different 'Purchased On' dates).
- Budget status and spending, including total and category-specific budgets.

Be concise and helpful. Today's date is ${new Date().toLocaleDateString()}.

Current Budget Info:
${budgetInfo}

Current & Past Inventory Data (This is also the complete purchase history):
${formattedInventory}

User's Question: "${question}"`;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "Sorry, I couldn't process that request. Please try again.";
  }
}

export async function getBudgetRecommendation(
  inventory: TrackedItem[]
): Promise<BudgetRecommendation | null> {
    if (!process.env.API_KEY) {
        throw new Error("API key not configured.");
    }
    
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);

    const recentHistory = inventory
        .filter(item => new Date(item.purchaseDate) >= threeMonthsAgo)
        .map(item => `Item: ${item.name}, Category: ${item.category}, Total Price: ${item.totalPrice.toFixed(2)} GHS, Purchased On: ${new Date(item.purchaseDate).toLocaleDateString()}.`)
        .join('\n');
        
    if (recentHistory.length < 1) {
        return null; // Not enough data for a recommendation
    }

    const categoryProperties = CATEGORIES.reduce((acc, cat) => {
        acc[cat] = { type: Type.NUMBER, description: `Budget for ${cat}` };
        return acc;
    }, {} as Record<string, { type: Type.NUMBER, description: string }>);

    const budgetRecommendationSchema = {
        type: Type.OBJECT,
        properties: {
            total: { type: Type.NUMBER, description: "The recommended total monthly budget, rounded to a whole number." },
            categories: {
                type: Type.OBJECT,
                properties: categoryProperties,
                description: "A recommended breakdown of the budget by category. Only include categories with significant spending. Round to a whole number."
            },
            reasoning: { type: Type.STRING, description: "A brief, friendly, one-sentence explanation for the recommendation." }
        },
        required: ["total", "categories", "reasoning"]
    };

    const prompt = `You are a helpful financial assistant for a grocery app. Your task is to recommend a monthly grocery budget based on the user's past spending habits.
Analyze the following purchase history from the last 3 months. Based on these spending patterns, recommend a realistic total monthly budget and a breakdown by category for the upcoming month.
The currency is Ghanaian Cedis (GHS), but do not include currency symbols in the numeric fields.
Provide a brief, friendly reasoning for your recommendation.

Past Spending Data:
---
${recentHistory}
---

Provide your recommendation in the specified JSON format.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: budgetRecommendationSchema,
            }
        });

        const jsonString = response.text.trim();
        const cleanedJsonString = jsonString.replace(/^```json\s*|```$/g, '');
        const parsed = JSON.parse(cleanedJsonString);
        
        return parsed as BudgetRecommendation;

    } catch (error) {
        console.error("Error getting budget recommendation:", error);
        throw new Error("Could not generate a budget recommendation at this time.");
    }
}