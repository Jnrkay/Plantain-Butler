import React, { useState, useEffect, useMemo } from 'react';
import { TrackedItem, Budget, MonthlyBudget } from './types';
import { Dashboard } from './components/Dashboard';
import { InventoryManager } from './components/InventoryManager';
import { BudgetTracker } from './components/BudgetTracker';
import { ShoppingList } from './components/ShoppingList';
import { FinanceTracker } from './components/FinanceTracker';
import { Assistant } from './components/Assistant';
import { AddItemModal } from './components/AddItemModal';
import { FileUploadModal } from './components/FileUploadModal';
import { DashboardIcon } from './components/icons/DashboardIcon';
import { InventoryIcon } from './components/icons/InventoryIcon';
import { ShoppingBagIcon } from './components/icons/ShoppingBagIcon';
import { FinanceIcon } from './components/icons/FinanceIcon';
import { HistoryIcon } from './components/icons/HistoryIcon';

const SAMPLE_ITEMS: TrackedItem[] = [
    {
        id: 'sample-1',
        name: 'Whole Chicken',
        category: 'Meat & Seafood',
        quantity: 1,
        initialQuantity: 1,
        unitPrice: 55.00,
        totalPrice: 55.00,
        purchaseDate: new Date().toISOString(),
        estimatedFinishDate: new Date(new Date().setDate(new Date().getDate() + 7)).toISOString(),
        isSample: true,
        lowStockThreshold: 1,
    },
    {
        id: 'sample-2',
        name: 'Fresh Milk (1L)',
        category: 'Dairy & Eggs',
        quantity: 1,
        initialQuantity: 1,
        unitPrice: 15.50,
        totalPrice: 15.50,
        purchaseDate: new Date().toISOString(),
        estimatedFinishDate: new Date(new Date().setDate(new Date().getDate() + 3)).toISOString(), 
        isSample: true,
        lowStockThreshold: 1,
    },
    {
        id: 'sample-3',
        name: 'Sliced Bread',
        category: 'Bakery',
        quantity: 1,
        initialQuantity: 1,
        unitPrice: 12.00,
        totalPrice: 12.00,
        purchaseDate: new Date().toISOString(),
        estimatedFinishDate: new Date(new Date().setDate(new Date().getDate() + 2)).toISOString(),
        isSample: true,
        lowStockThreshold: 2, // This will put it on the shopping list immediately
    },
];

type Tab = 'Dashboard' | 'Inventory' | 'Shopping List' | 'Budget' | 'History';

const App: React.FC = () => {
    const [trackedItems, setTrackedItems] = useState<TrackedItem[]>(() => {
        try {
            const itemsJSON = localStorage.getItem('trackedItems');
            if (!itemsJSON) return SAMPLE_ITEMS;
            
            const items = JSON.parse(itemsJSON);
             // Data migration for items without initialQuantity
            return items.map((item: any) => ({
                ...item,
                initialQuantity: item.initialQuantity ?? item.quantity,
            }));
        } catch (error) {
            return SAMPLE_ITEMS;
        }
    });

    const [consumptionPatterns, setConsumptionPatterns] = useState<Record<string, number>>(() => {
        try {
            const patternsJSON = localStorage.getItem('consumptionPatterns');
            return patternsJSON ? JSON.parse(patternsJSON) : {};
        } catch (error) {
            return {};
        }
    });

    const [budgets, setBudgets] = useState<Budget>(() => {
        try {
            const budgetsJSON = localStorage.getItem('budgets');
            return budgetsJSON ? JSON.parse(budgetsJSON) : {};
        } catch {
            return {};
        }
    });

    const [activeTab, setActiveTab] = useState<Tab>('Dashboard');
    const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

    // Modal States
    const [isAddItemModalOpen, setIsAddItemModalOpen] = useState(false);
    const [itemToEdit, setItemToEdit] = useState<Omit<TrackedItem, 'id'> | TrackedItem | null>(null);
    const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

    // Effect for automatic quantity depletion
    useEffect(() => {
        const today = new Date().getTime();
        let hasChanged = false;

        const updatedItems = trackedItems.map(item => {
            if (!item.estimatedFinishDate || !item.initialQuantity) {
                return item;
            }

            const purchaseDate = new Date(item.purchaseDate).getTime();
            const finishDate = new Date(item.estimatedFinishDate).getTime();

            if (today >= finishDate) {
                if (item.quantity !== 0) {
                    hasChanged = true;
                    return { ...item, quantity: 0, totalPrice: 0 };
                }
                return item;
            }

            if (today <= purchaseDate) {
                 if (item.quantity !== item.initialQuantity) {
                     hasChanged = true;
                     return { ...item, quantity: item.initialQuantity, totalPrice: item.initialQuantity * item.unitPrice };
                 }
                return item;
            }

            const totalDuration = finishDate - purchaseDate;
            if (totalDuration <= 0) return item;

            const elapsedDuration = today - purchaseDate;
            const consumptionRatio = elapsedDuration / totalDuration;
            
            const consumedQuantity = item.initialQuantity * consumptionRatio;
            const remainingQuantity = item.initialQuantity - consumedQuantity;
            
            const newQuantity = Math.max(0, Math.floor(remainingQuantity));

            if (newQuantity !== item.quantity) {
                hasChanged = true;
                return {
                    ...item,
                    quantity: newQuantity,
                    totalPrice: newQuantity * item.unitPrice
                };
            }

            return item;
        });

        if (hasChanged) {
            setTrackedItems(updatedItems);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    useEffect(() => {
        try {
            localStorage.setItem('trackedItems', JSON.stringify(trackedItems));
        } catch (error) {
            console.error("Failed to save items to localStorage", error);
        }
    }, [trackedItems]);

    useEffect(() => {
        try {
            localStorage.setItem('consumptionPatterns', JSON.stringify(consumptionPatterns));
        } catch (error) {
            console.error("Failed to save consumption patterns to localStorage", error);
        }
    }, [consumptionPatterns]);

    useEffect(() => {
        try {
            localStorage.setItem('budgets', JSON.stringify(budgets));
        } catch (error) {
            console.error("Failed to save budgets to localStorage", error);
        }
    }, [budgets]);

    const handleAddItem = (item: Omit<TrackedItem, 'id'>) => {
        const itemNameKey = item.name.trim().toLowerCase();
        const learnedDays = consumptionPatterns[itemNameKey];
        
        let finalItem = { ...item };

        if (learnedDays && item.quantity > 0) {
            const finishDate = new Date();
            finishDate.setDate(finishDate.getDate() + learnedDays * item.quantity);
            finalItem.estimatedFinishDate = finishDate.toISOString();
        }

        const newItem: TrackedItem = {
            ...finalItem,
            id: `${Date.now()}-${item.name}-${Math.random()}`,
            initialQuantity: item.quantity,
        };
        setTrackedItems(prev => {
             const withoutSample = prev.filter(item => !item.isSample);
            return [...withoutSample, newItem].sort((a,b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());
        });
    };
    
    const handleAddMultipleItems = (newItems: Omit<TrackedItem, 'id'>[]) => {
        const itemsWithMetaData = newItems.map(item => {
             const itemNameKey = item.name.trim().toLowerCase();
            const learnedDays = consumptionPatterns[itemNameKey];
            
            let finalItem = { ...item };
            if (learnedDays && item.quantity > 0) {
                const finishDate = new Date();
                finishDate.setDate(finishDate.getDate() + learnedDays * item.quantity);
                finalItem.estimatedFinishDate = finishDate.toISOString();
            }

            return {
                ...finalItem,
                id: `${Date.now()}-${item.name}-${Math.random()}`,
                initialQuantity: item.quantity,
            }
        });
        
        setTrackedItems(prev => {
            const withoutSample = prev.filter(item => !item.isSample);
            return [...withoutSample, ...itemsWithMetaData].sort((a,b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());
        });
    };

    const handleUpdateItem = (updatedItem: TrackedItem) => {
        const oldItem = trackedItems.find(item => item.id === updatedItem.id);

        if (oldItem && oldItem.quantity > 0 && updatedItem.quantity <= 0) {
            const purchaseDate = new Date(oldItem.purchaseDate);
            const finishDate = new Date(); // Assume it finished today
            const durationMs = finishDate.getTime() - purchaseDate.getTime();
            
            if (durationMs > 1000 * 60 * 60 * 24 && oldItem.initialQuantity > 0) {
                const durationDays = durationMs / (1000 * 60 * 60 * 24);
                const daysPerUnit = durationDays / oldItem.initialQuantity;
                
                const itemNameKey = oldItem.name.trim().toLowerCase();
                const existingPattern = consumptionPatterns[itemNameKey];
                const newAvg = existingPattern ? (existingPattern * 0.25 + daysPerUnit * 0.75) : daysPerUnit;
                
                setConsumptionPatterns(prev => ({
                    ...prev,
                    [itemNameKey]: parseFloat(newAvg.toFixed(2))
                }));
            }
        }

        setTrackedItems(prev => prev.map(item => item.id === updatedItem.id ? updatedItem : item));
    };

    const handleDeleteItem = (itemId: string) => {
        setTrackedItems(prev => prev.filter(item => item.id !== itemId));
    };

    const handleUpdateBudget = (monthKey: string, budget: MonthlyBudget | null) => {
        setBudgets(prev => {
            const newBudgets = { ...prev };
            if (budget) {
                newBudgets[monthKey] = budget;
            } else {
                delete newBudgets[monthKey];
            }
            return newBudgets;
        });
    };

    const shoppingListItems = useMemo(() => 
        trackedItems.filter(item => item.quantity <= item.lowStockThreshold)
    , [trackedItems]);

    // Modal Handlers
    const handleOpenAddItemModal = (item: Omit<TrackedItem, 'id'> | TrackedItem | null = null) => {
        setItemToEdit(item);
        setIsAddItemModalOpen(true);
    };
    const handleCloseAddItemModal = () => setIsAddItemModalOpen(false);
    
    const handleOpenUploadModal = () => setIsUploadModalOpen(true);
    const handleCloseUploadModal = () => setIsUploadModalOpen(false);

    const handleSaveItem = (item: Omit<TrackedItem, 'id'> | TrackedItem) => {
        if ('id' in item) {
            handleUpdateItem(item as TrackedItem);
        } else {
            handleAddItem(item as Omit<TrackedItem, 'id'>);
        }
        handleCloseAddItemModal();
    };
    
    const handleAddMultipleAndClose = (items: Omit<TrackedItem, 'id'>[]) => {
      handleAddMultipleItems(items);
      handleCloseUploadModal();
    }
    
    const handleLogPurchaseFromList = (itemToLog: TrackedItem) => {
        const lastPurchase = [...trackedItems]
            .filter(item => item.name.trim().toLowerCase() === itemToLog.name.trim().toLowerCase())
            .sort((a, b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime())[0];
        
        const quantity = lastPurchase?.initialQuantity || 1;
        const unitPrice = lastPurchase?.unitPrice || 0;
        
        const prefilledItem = {
            name: itemToLog.name,
            category: lastPurchase?.category || itemToLog.category,
            quantity,
            initialQuantity: quantity,
            unitPrice,
            totalPrice: quantity * unitPrice,
            purchaseDate: new Date().toISOString(),
            lowStockThreshold: lastPurchase?.lowStockThreshold || 1,
            durationPerUnit: lastPurchase?.durationPerUnit,
            durationUnit: lastPurchase?.durationUnit,
        };
        
        handleOpenAddItemModal(prefilledItem);
    };


    const renderContent = () => {
        switch (activeTab) {
            case 'Dashboard':
                return <Dashboard 
                            trackedItems={trackedItems} 
                            shoppingListCount={shoppingListItems.length} 
                            budgets={budgets}
                            onNavigate={setActiveTab as (tab: 'Inventory' | 'Shopping List' | 'Budget') => void} 
                            onRequestAddItem={handleOpenAddItemModal}
                            onRequestUpload={handleOpenUploadModal}
                        />;
            case 'Inventory':
                return <InventoryManager 
                          inventory={trackedItems} 
                          onUpdateItem={handleUpdateItem} 
                          onDeleteItem={handleDeleteItem}
                          onOpenAddItemModal={handleOpenAddItemModal}
                          onOpenUploadModal={handleOpenUploadModal}
                        />;
            case 'Shopping List':
                 return <ShoppingList items={shoppingListItems} onLogPurchase={handleLogPurchaseFromList} />;
            case 'Budget':
                return <BudgetTracker items={trackedItems} budgets={budgets} onUpdateBudget={handleUpdateBudget} />;
            case 'History':
                return <FinanceTracker items={trackedItems} />;
            default:
                return null;
        }
    };

    const NavLink: React.FC<{ tab: Tab; icon: React.ReactNode; children: React.ReactNode }> = ({ tab, icon, children }) => (
        <a
            href="#"
            onClick={(e) => {
                e.preventDefault();
                setActiveTab(tab);
                setIsMobileNavOpen(false);
            }}
            className={`flex items-center px-4 py-3 text-lg rounded-lg transition-colors ${
                activeTab === tab 
                ? 'bg-primary-600 text-white shadow-md' 
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
        >
            <span className="mr-3">{icon}</span>
            {children}
        </a>
    );

    return (
        <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100 font-sans flex">
            {/* Sidebar */}
            <aside className={`bg-white dark:bg-gray-800 w-64 flex-shrink-0 p-4 space-y-4 fixed inset-y-0 left-0 z-30 transform ${isMobileNavOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out md:relative md:translate-x-0`}>
                <h1 className="text-2xl font-bold text-primary-600 dark:text-primary-400 px-2">
                    Grocery Intel
                </h1>
                <nav className="flex flex-col space-y-2">
                    <NavLink tab="Dashboard" icon={<DashboardIcon className="w-6 h-6" />} >Dashboard</NavLink>
                    <NavLink tab="Inventory" icon={<InventoryIcon className="w-6 h-6" />}>Inventory</NavLink>
                    <NavLink tab="Shopping List" icon={<ShoppingBagIcon className="w-6 h-6" />}>Shopping List</NavLink>
                    <NavLink tab="Budget" icon={<FinanceIcon className="w-6 h-6" />}>Budget</NavLink>
                    <NavLink tab="History" icon={<HistoryIcon className="w-6 h-6" />}>History</NavLink>
                </nav>
            </aside>
            
            {/* Mobile Nav Overlay */}
            {isMobileNavOpen && <div className="fixed inset-0 bg-black/50 z-20 md:hidden" onClick={() => setIsMobileNavOpen(false)}></div>}

            <div className="flex-1 flex flex-col">
                 <header className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm shadow-sm sticky top-0 z-10 flex items-center justify-between p-4 md:hidden">
                    <h1 className="text-xl font-bold text-primary-600 dark:text-primary-400">
                        {activeTab}
                    </h1>
                    <button onClick={() => setIsMobileNavOpen(true)} className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                        </svg>
                    </button>
                </header>
                <main className="flex-1 p-4 sm:p-6 lg:p-8">
                    {renderContent()}
                </main>
            </div>

            <AddItemModal 
                isOpen={isAddItemModalOpen}
                onClose={handleCloseAddItemModal}
                onSave={handleSaveItem}
                itemToEdit={itemToEdit}
            />
            <FileUploadModal
                isOpen={isUploadModalOpen}
                onClose={handleCloseUploadModal}
                onAddMultipleItems={handleAddMultipleAndClose}
            />

            <Assistant items={trackedItems} budgets={budgets} />
        </div>
    );
};

export default App;