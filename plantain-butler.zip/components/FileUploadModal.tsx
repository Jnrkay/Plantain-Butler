import React, { useState, useCallback, useEffect } from 'react';
import { TrackedItem } from '../types';
import { Modal } from './common/Modal';
import { UploadIcon } from './icons/UploadIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { parseReceipt, parseStructuredData } from '../services/geminiService';
import * as pdfjsLib from 'pdfjs-dist';
import * as XLSX from 'xlsx';

pdfjsLib.GlobalWorkerOptions.workerSrc = `https://aistudiocdn.com/pdfjs-dist@^4.6.391/build/pdf.worker.mjs`;

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = error => reject(error);
  });
};

const fileToText = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsText(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};

const fileToPdfText = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
    let fullText = '';
    for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        fullText += textContent.items.map(item => (item as any).str).join(' ');
    }
    return fullText;
};

const fileToExcelText = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    return XLSX.utils.sheet_to_csv(worksheet);
};

interface FileUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddMultipleItems: (items: Omit<TrackedItem, 'id'>[]) => void;
}

export const FileUploadModal: React.FC<FileUploadModalProps> = ({ isOpen, onClose, onAddMultipleItems }) => {
  const [isUploading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);

  const handleFile = useCallback(async (file: File) => {
    setError(null);
    setIsLoading(true);
    try {
        let newItems: Omit<TrackedItem, 'id'>[] = [];
        if (file.type.startsWith('image/')) {
            const base64Image = await fileToBase64(file);
            newItems = await parseReceipt(base64Image, file.type);
        } else if (file.type === 'text/plain' || file.type === 'text/csv') {
            const textContent = await fileToText(file);
            newItems = await parseStructuredData(textContent);
        } else if (file.type === 'application/pdf') {
            const textContent = await fileToPdfText(file);
            newItems = await parseStructuredData(textContent);
        } else if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
            const textContent = await fileToExcelText(file);
            newItems = await parseStructuredData(textContent);
        } else {
            throw new Error(`Unsupported file type: '${file.type}'. Please upload an image, txt, csv, pdf, or excel file.`);
        }
        
        onAddMultipleItems(newItems);
        onClose();
    } catch (e: any) {
        setError(e.message || 'An unknown error occurred.');
    } finally {
        setIsLoading(false);
    }
  }, [onAddMultipleItems, onClose]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") setDragActive(true);
    else if (e.type === "dragleave") setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault(); e.stopPropagation(); setDragActive(false);
    if (e.dataTransfer.files?.[0]) handleFile(e.dataTransfer.files[0]);
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files?.[0]) handleFile(e.target.files[0]);
  };

  // Reset state on close
  useEffect(() => {
    if (!isOpen) {
        setError(null);
        setIsLoading(false);
        setDragActive(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Upload a File">
      <form onDragEnter={handleDrag} onSubmit={(e) => e.preventDefault()} className="relative text-center">
        <label htmlFor="receipt-upload" className={`flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${dragActive ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20' : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'}`}>
        {isUploading ? (
            <div className="flex flex-col items-center"><SpinnerIcon className="w-10 h-10 text-primary-500"/><p className="mt-2 text-sm font-semibold">Analyzing...</p></div>
        ) : (
            <><UploadIcon className="w-10 h-10 text-gray-500 dark:text-gray-400 mb-2"/><p className="mb-2 text-sm"><span className="font-semibold">Click to upload</span> or drag and drop</p><p className="text-xs text-gray-500 dark:text-gray-400">Image, TXT, CSV, PDF, or Excel files</p></>
        )}
        </label>
        <input id="receipt-upload" type="file" className="hidden" accept="image/*,text/plain,text/csv,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={handleChange} disabled={isUploading} />
        {dragActive && <div className="absolute inset-0 w-full h-full" onDragEnter={handleDrag} onDragLeave={handleDrag} onDragOver={handleDrag} onDrop={handleDrop}></div>}
    </form>
    {error && <p className="text-red-500 text-sm mt-2 text-center">{error}</p>}
    </Modal>
  );
};