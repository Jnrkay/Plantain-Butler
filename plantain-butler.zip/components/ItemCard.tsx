import React from 'react';
import { TrackedItem } from '../types';
import { Card } from './common/Card';

interface ItemCardProps {
    item: TrackedItem;
}

export const ItemCard: React.FC<ItemCardProps> = ({ item }) => {
    return (
        <Card className="flex flex-col justify-between">
            <div>
                <div className="flex justify-between items-start">
                    <h3 className="text-lg font-bold text-gray-800 dark:text-white">{item.name}</h3>
                    <span className="text-sm font-medium bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200 px-2 py-1 rounded-full">{item.category}</span>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Purchased on {new Date(item.purchaseDate).toLocaleDateString()}
                </p>
            </div>
            <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-between items-baseline">
                <div className="text-sm text-gray-600 dark:text-gray-300">
                    {item.quantity} x {item.unitPrice.toFixed(2)} GHS
                </div>
                <div className="text-xl font-bold text-primary-600 dark:text-primary-400">
                    {item.totalPrice.toFixed(2)}
                    <span className="text-sm font-normal ml-1">GHS</span>
                </div>
            </div>
        </Card>
    );
};
