import React, { useMemo } from 'react';
import { TrackedItem, Category } from '../types';
import { Card } from './common/Card';
import { ShoppingBagIcon } from './icons/ShoppingBagIcon';
import { Button } from './common/Button';

interface ShoppingListProps {
  items: TrackedItem[];
  onLogPurchase: (item: TrackedItem) => void;
}

export const ShoppingList: React.FC<ShoppingListProps> = ({ items, onLogPurchase }) => {

  const groupedItems = useMemo(() => {
    return items.reduce((acc, item) => {
        const category = item.category || 'Other';
        if (!acc[category]) {
            acc[category] = [];
        }
        acc[category].push(item);
        return acc;
    }, {} as Record<Category | 'Other', TrackedItem[]>);
  }, [items]);

  const categoryOrder = Object.keys(groupedItems).sort();


  return (
    <div className="space-y-6">
       <div>
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Shopping List</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">Here are the items you're running low on. Log them as you shop!</p>
        </div>
        <Card>
          {items.length > 0 ? (
            <div className="space-y-6">
              {categoryOrder.map(category => (
                <div key={category}>
                  <h2 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-3 pb-2 border-b border-gray-200 dark:border-gray-700">{category}</h2>
                  <ul className="space-y-3">
                    {groupedItems[category as Category].map(item => (
                      <li key={item.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <div>
                          <p className="text-lg font-medium text-gray-900 dark:text-gray-100">{item.name}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            Currently: <span className="font-medium text-yellow-600 dark:text-yellow-400">{item.quantity}</span> / Low at {item.lowStockThreshold}
                          </p>
                        </div>
                        <Button onClick={() => onLogPurchase(item)} variant="secondary" className="flex-shrink-0">
                          Log Purchase
                        </Button>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
                <ShoppingBagIcon className="w-16 h-16 mx-auto text-green-500" />
                <h3 className="mt-4 text-xl font-semibold text-gray-700 dark:text-gray-200">Your shopping list is empty!</h3>
                <p className="mt-2 text-gray-500 dark:text-gray-400">You're all stocked up. Great job!</p>
            </div>
          )}
        </Card>
    </div>
  );
};