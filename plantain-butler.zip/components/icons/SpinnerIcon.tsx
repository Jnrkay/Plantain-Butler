import React from 'react';
export const SpinnerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`animate-spin ${props.className}`}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v3m0 12v3m9-9h-3m-12 0H3m16.03-6.03-2.12 2.12M5.09 18.91l2.12-2.12M18.91 5.09l-2.12 2.12M5.09 5.09l2.12 2.12" />
    </svg>
);
