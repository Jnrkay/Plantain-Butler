import React from 'react';
export const ChatIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.76 9.76 0 0 1-2.53-.388A5.863 5.863 0 0 1 5.12 20.42a.388.388 0 0 0-.32.321 7.468 7.468 0 0 1-2.098 2.098c-.145.145-.33.22-.53.22a.5.5 0 0 1-.5-.5c0-.2.075-.385.22-.53a7.468 7.468 0 0 1 2.098-2.098.388.388 0 0 0 .321-.32 5.863 5.863 0 0 1-.388-2.53C3 7.444 7.03 3.75 12 3.75s9 3.694 9 8.25Z" />
  </svg>
);
