import React, { useState, useMemo } from 'react';
import { TrackedItem, Category } from '../types';
import { Card } from './common/Card';
import { CATEGORIES } from '../constants';
import { FinanceIcon } from './icons/FinanceIcon';
import { InventoryIcon } from './icons/InventoryIcon';

type DateRange = 'all' | '7d' | '30d' | '90d';

interface FinanceTrackerProps {
  items: TrackedItem[];
}

export const FinanceTracker: React.FC<FinanceTrackerProps> = ({ items }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [filterCategory, setFilterCategory] = useState<Category | 'all'>('all');
    const [dateRange, setDateRange] = useState<DateRange>('30d');

    const filteredItems = useMemo(() => {
        const now = new Date();
        let startDate = new Date(0); // Beginning of time for 'all'

        if (dateRange !== 'all') {
            const daysToSubtract = { '7d': 7, '30d': 30, '90d': 90 }[dateRange];
            startDate = new Date(new Date().setDate(now.getDate() - daysToSubtract));
        }

        return items
            .filter(item => {
                const purchaseDate = new Date(item.purchaseDate);
                const matchesDate = dateRange === 'all' || purchaseDate >= startDate;
                const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
                const matchesCategory = filterCategory === 'all' || item.category === filterCategory;
                return matchesDate && matchesSearch && matchesCategory;
            })
            .sort((a, b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());
    }, [items, searchTerm, filterCategory, dateRange]);

    const summary = useMemo(() => {
        return {
            totalSpent: filteredItems.reduce((acc, item) => acc + (item.initialQuantity * item.unitPrice), 0),
            itemCount: filteredItems.length,
        };
    }, [filteredItems]);

    const dateRangeOptions: { value: DateRange; label: string }[] = [
        { value: '7d', label: 'Last 7 Days' },
        { value: '30d', label: 'Last 30 Days' },
        { value: '90d', label: 'Last 90 Days' },
        { value: 'all', label: 'All Time' },
    ];

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Spending History</h1>
                <p className="text-gray-600 dark:text-gray-400 mt-1">Review and analyze your past purchases.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <Card>
                    <div className="flex items-center">
                        <div className="p-3 bg-green-100 dark:bg-green-900/50 rounded-lg mr-4">
                            <FinanceIcon className="w-6 h-6 text-green-600 dark:text-green-300" />
                        </div>
                        <div>
                            <h3 className="font-bold text-lg text-gray-700 dark:text-gray-200">Total Spent</h3>
                             <p className="text-3xl font-bold text-green-600 dark:text-green-400 mt-1">
                                {summary.totalSpent.toFixed(2)}
                                <span className="text-sm font-medium text-gray-500 dark:text-gray-400 ml-1">GHS</span>
                             </p>
                        </div>
                    </div>
                 </Card>
                 <Card>
                     <div className="flex items-center">
                        <div className="p-3 bg-primary-100 dark:bg-primary-900/50 rounded-lg mr-4">
                            <InventoryIcon className="w-6 h-6 text-primary-600 dark:text-primary-300" />
                        </div>
                        <div>
                            <h3 className="font-bold text-lg text-gray-700 dark:text-gray-200">Items Purchased</h3>
                            <p className="text-3xl font-bold text-primary-600 dark:text-primary-400 mt-1">{summary.itemCount}</p>
                        </div>
                    </div>
                 </Card>
            </div>
            
            <Card>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <input 
                        type="text" placeholder="Search items..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 border border-transparent rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                    <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value as Category | 'all')}
                        className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 border border-transparent rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                        <option value="all">All Categories</option>
                        {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </select>
                     <select value={dateRange} onChange={(e) => setDateRange(e.target.value as DateRange)}
                        className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 border border-transparent rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                        {dateRangeOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                    </select>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" className="px-6 py-3">Item Name</th>
                                <th scope="col" className="px-6 py-3">Category</th>
                                <th scope="col" className="px-6 py-3 hidden md:table-cell">Purchase Date</th>
                                <th scope="col" className="px-6 py-3">Quantity</th>
                                <th scope="col" className="px-6 py-3 hidden sm:table-cell">Unit Price (GHS)</th>
                                <th scope="col" className="px-6 py-3">Total Price (GHS)</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredItems.length > 0 ? (
                                filteredItems.map(item => (
                                    <tr key={item.id} className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                        <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">{item.name}</th>
                                        <td className="px-6 py-4">{item.category}</td>
                                        <td className="px-6 py-4 hidden md:table-cell">{new Date(item.purchaseDate).toLocaleDateString()}</td>
                                        <td className="px-6 py-4">{item.initialQuantity}</td>
                                        <td className="px-6 py-4 hidden sm:table-cell">{item.unitPrice.toFixed(2)}</td>
                                        <td className="px-6 py-4 font-medium">{(item.initialQuantity * item.unitPrice).toFixed(2)}</td>
                                    </tr>
                                ))
                            ) : (
                                <tr><td colSpan={6} className="text-center py-8">No purchases found for the selected filters.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};
