import React, { useMemo } from 'react';
import { TrackedItem, Budget } from '../types';
import { Card } from './common/Card';
import { Button } from './common/Button';
import { InventoryIcon } from './icons/InventoryIcon';
import { FinanceIcon } from './icons/FinanceIcon';
import { ShoppingBagIcon } from './icons/ShoppingBagIcon';
import { UploadIcon } from './icons/UploadIcon';
import { PlusIcon } from './icons/PlusIcon';
import { CalendarIcon } from './icons/CalendarIcon';
import { TrendingUpIcon } from './icons/TrendingUpIcon';

interface ShoppingForecastProps {
    items: TrackedItem[];
}

const ShoppingForecast: React.FC<ShoppingForecastProps> = ({ items }) => {
    const upcomingItems = useMemo(() => {
        const today = new Date();
        const forecastLimit = new Date();
        forecastLimit.setDate(today.getDate() + 5);

        return items
            .filter(item => 
                item.estimatedFinishDate &&
                new Date(item.estimatedFinishDate) > today &&
                new Date(item.estimatedFinishDate) <= forecastLimit
            )
            .sort((a, b) => new Date(a.estimatedFinishDate!).getTime() - new Date(b.estimatedFinishDate!).getTime());
    }, [items]);

    if (upcomingItems.length < 1) {
        return null; 
    }

    const daysUntilNextShopping = upcomingItems.length > 0
        ? Math.max(1, Math.ceil((new Date(upcomingItems[0].estimatedFinishDate!).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)))
        : 0;
    
    const dayString = daysUntilNextShopping <= 1 ? 'day' : 'days';

    return (
        <Card className="bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 col-span-1 md:col-span-2 lg:col-span-3 xl:col-span-4">
            <div className="flex items-center">
                <div className="p-3 bg-blue-100 dark:bg-blue-900/50 rounded-lg mr-4">
                    <CalendarIcon className="w-6 h-6 text-blue-600 dark:text-blue-300" />
                </div>
                <div>
                    <h3 className="font-bold text-lg text-blue-800 dark:text-blue-200">Shopping Forecast</h3>
                    <p className="text-blue-600 dark:text-blue-300 mt-1">
                        You'll likely need a shopping trip in about <span className="font-bold">{daysUntilNextShopping} {dayString}</span>.
                    </p>
                </div>
            </div>
            <div className="mt-4 pl-4">
                <p className="text-sm text-blue-500 dark:text-blue-400 mb-2 font-semibold">Running low soon:</p>
                <ul className="list-disc list-inside text-blue-700 dark:text-blue-300 space-y-1">
                    {upcomingItems.slice(0, 3).map(item => (
                        <li key={item.id}>{item.name}</li>
                    ))}
                    {upcomingItems.length > 3 && <li>and {upcomingItems.length - 3} more...</li>}
                </ul>
            </div>
        </Card>
    );
};


interface DashboardProps {
  trackedItems: TrackedItem[];
  shoppingListCount: number;
  budgets: Budget;
  onNavigate: (tab: 'Inventory' | 'Shopping List' | 'Budget') => void;
  onRequestAddItem: () => void;
  onRequestUpload: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ trackedItems, shoppingListCount, budgets, onNavigate, onRequestAddItem, onRequestUpload }) => {

  const { 
      totalSpentThisMonth, currentBudget, budgetProgress,
      spendThisWeek, weeklyTarget, weeklyProgress, weeklyStatus 
  } = useMemo(() => {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    const currentMonthKey = today.toISOString().slice(0, 7);

    // Monthly spend
    const monthlySpend = trackedItems
      .filter(item => {
        const itemDate = new Date(item.purchaseDate);
        return itemDate.getMonth() === currentMonth && itemDate.getFullYear() === currentYear;
      })
      .reduce((sum, item) => sum + item.totalPrice, 0);

    const monthlyBudget = budgets[currentMonthKey]?.total || 0;
    const monthlyProg = monthlyBudget > 0 ? (monthlySpend / monthlyBudget) * 100 : 0;
    
    // Weekly Pace
    const weeklyBudgetTarget = monthlyBudget / 4; // Simple approximation

    // Calculate start and end of the week (Sunday - Saturday)
    const firstDayOfWeek = new Date(today);
    firstDayOfWeek.setDate(today.getDate() - today.getDay());
    firstDayOfWeek.setHours(0, 0, 0, 0);

    const lastDayOfWeek = new Date(firstDayOfWeek);
    lastDayOfWeek.setDate(firstDayOfWeek.getDate() + 6);
    lastDayOfWeek.setHours(23, 59, 59, 999);

    const weeklySpend = trackedItems
      .filter(item => {
        const itemDate = new Date(item.purchaseDate);
        return itemDate >= firstDayOfWeek && itemDate <= lastDayOfWeek;
      })
      .reduce((sum, item) => sum + item.totalPrice, 0);
      
    const weeklyProg = weeklyBudgetTarget > 0 ? (weeklySpend / weeklyBudgetTarget) * 100 : 0;
    
    let status = { text: 'Set a monthly budget to see your weekly pace.', color: 'text-gray-500 dark:text-gray-400' };
    if (weeklyBudgetTarget > 0) {
        if (weeklyProg <= 75) {
            status = { text: "You're on track for the week!", color: 'text-green-600 dark:text-green-400' };
        } else if (weeklyProg <= 100) {
            status = { text: 'Nearing your weekly limit.', color: 'text-yellow-600 dark:text-yellow-400' };
        } else {
            status = { text: 'You are over your weekly pace.', color: 'text-red-600 dark:text-red-400' };
        }
    }

    return { 
        totalSpentThisMonth: monthlySpend, 
        currentBudget: monthlyBudget, 
        budgetProgress: monthlyProg,
        spendThisWeek: weeklySpend,
        weeklyTarget: weeklyBudgetTarget,
        weeklyProgress: weeklyProg,
        weeklyStatus: status
    };
  }, [trackedItems, budgets]);

  return (
    <div className="space-y-6">
        <div>
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Dashboard</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">Here's a quick overview of your grocery status.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <ShoppingForecast items={trackedItems} />

            <Card>
                <div className="flex items-center">
                    <div className="p-3 bg-primary-100 dark:bg-primary-900/50 rounded-lg mr-4">
                        <InventoryIcon className="w-6 h-6 text-primary-600 dark:text-primary-300" />
                    </div>
                    <div>
                        <h3 className="font-bold text-lg text-gray-700 dark:text-gray-200">Total Items</h3>
                        <p className="text-3xl font-bold text-primary-600 dark:text-primary-400 mt-1">{trackedItems.length}</p>
                    </div>
                </div>
                <Button onClick={() => onNavigate('Inventory')} className="mt-4 w-full">Manage Inventory</Button>
            </Card>
            
            <Card>
                 <div className="flex items-center">
                    <div className="p-3 bg-yellow-100 dark:bg-yellow-900/50 rounded-lg mr-4">
                        <ShoppingBagIcon className="w-6 h-6 text-yellow-600 dark:text-yellow-300" />
                    </div>
                    <div>
                        <h3 className="font-bold text-lg text-gray-700 dark:text-gray-200">Shopping List</h3>
                        <p className="text-3xl font-bold text-yellow-600 dark:text-yellow-400 mt-1">{shoppingListCount}</p>
                    </div>
                </div>
                <Button onClick={() => onNavigate('Shopping List')} className="mt-4 w-full bg-yellow-500 hover:bg-yellow-600 focus:ring-yellow-400 text-white">View List</Button>
            </Card>
            
            <Card>
                <div className="flex flex-col h-full">
                    <div className="flex items-center">
                        <div className="p-3 bg-indigo-100 dark:bg-indigo-900/50 rounded-lg mr-4">
                            <TrendingUpIcon className="w-6 h-6 text-indigo-600 dark:text-indigo-300" />
                        </div>
                        <div>
                            <h3 className="font-bold text-lg text-gray-700 dark:text-gray-200">This Week's Pace</h3>
                             <p className="text-2xl font-bold text-indigo-600 dark:text-indigo-400 mt-1">
                                {spendThisWeek.toFixed(2)}
                                {weeklyTarget > 0 && (
                                    <span className="text-lg font-medium text-gray-500 dark:text-gray-400"> / {weeklyTarget.toFixed(2)}</span>
                                )}
                                <span className="text-sm font-medium text-gray-500 dark:text-gray-400 ml-1">GHS</span>
                             </p>
                        </div>
                    </div>
                     {weeklyTarget > 0 && (
                        <div className="mt-2 space-y-2">
                            <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                                <div className="bg-indigo-600 h-2.5 rounded-full" style={{ width: `${Math.min(weeklyProgress, 100)}%` }}></div>
                            </div>
                             <p className={`text-sm font-semibold text-center ${weeklyStatus.color}`}>
                                {weeklyStatus.text}
                            </p>
                        </div>
                    )}
                    {weeklyTarget <= 0 && (
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-2 text-center h-full flex items-center justify-center">
                            {weeklyStatus.text}
                        </p>
                    )}
                    <div className="flex-grow"></div>
                    <Button onClick={() => onNavigate('Budget')} className="mt-4 w-full bg-indigo-500 hover:bg-indigo-600 focus:ring-indigo-400 text-white">Manage Budget</Button>
                </div>
            </Card>

            <Card>
                <div className="flex flex-col h-full">
                    <div className="flex items-center">
                        <div className="p-3 bg-green-100 dark:bg-green-900/50 rounded-lg mr-4">
                            <FinanceIcon className="w-6 h-6 text-green-600 dark:text-green-300" />
                        </div>
                        <div>
                            <h3 className="font-bold text-lg text-gray-700 dark:text-gray-200">This Month's Spend</h3>
                             <p className="text-2xl font-bold text-green-600 dark:text-green-400 mt-1">
                                {totalSpentThisMonth.toFixed(2)}
                                {currentBudget > 0 && (
                                    <span className="text-lg font-medium text-gray-500 dark:text-gray-400"> / {currentBudget.toFixed(2)}</span>
                                )}
                                <span className="text-sm font-medium text-gray-500 dark:text-gray-400 ml-1">GHS</span>
                             </p>
                        </div>
                    </div>
                    {currentBudget > 0 && (
                        <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700 mt-2">
                            <div className="bg-green-600 h-2.5 rounded-full" style={{ width: `${Math.min(budgetProgress, 100)}%` }}></div>
                        </div>
                    )}
                    <Button onClick={() => onNavigate('Budget')} className="mt-4 w-full bg-green-500 hover:bg-green-600 focus:ring-green-400 text-white">View Budget</Button>
                </div>
            </Card>
            
            <Card className="border-2 border-dashed border-gray-300 dark:border-gray-600 flex flex-col items-center justify-center text-center bg-gray-50 dark:bg-gray-800/50 md:col-span-2 lg:col-span-4 xl:col-span-2">
                <h3 className="font-bold text-lg text-gray-700 dark:text-gray-200">Add New Items</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 mb-4">Quickly populate your inventory.</p>
                <div className="flex flex-col sm:flex-row gap-2 w-full">
                    <Button onClick={onRequestUpload} variant="secondary" className="w-full flex items-center justify-center gap-2">
                        <UploadIcon className="w-5 h-5" /> Upload File
                    </Button>
                    <Button onClick={onRequestAddItem} className="w-full flex items-center justify-center gap-2">
                        <PlusIcon className="w-5 h-5" /> Add Manually
                    </Button>
                </div>
            </Card>
        </div>
    </div>
  );
};