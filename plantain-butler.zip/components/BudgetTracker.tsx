import React, { useState, useMemo, useEffect } from 'react';
import { TrackedItem, Budget, Category, MonthlyBudget } from '../types';
import { Card } from './common/Card';
import { Button } from './common/Button';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { CATEGORIES } from '../constants';
import { getBudgetRecommendation } from '../services/geminiService';
import { SparklesIcon } from './icons/SparklesIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d', '#ffc658', '#a4de6c', '#d0ed57', '#ffc658', '#8dd1e1'];

interface BudgetTrackerProps {
  items: TrackedItem[];
  budgets: Budget;
  onUpdateBudget: (monthKey: string, budget: MonthlyBudget | null) => void;
}

export const BudgetTracker: React.FC<BudgetTrackerProps> = ({ items, budgets, onUpdateBudget }) => {
  const [viewMode, setViewMode] = useState<'monthly' | 'annual'>('monthly');
  
  const [totalBudgetInput, setTotalBudgetInput] = useState('');
  const [categoryBudgetsInput, setCategoryBudgetsInput] = useState<{[key in Category]?: string}>({});
  const [showCategoryBudgets, setShowCategoryBudgets] = useState(false);
  
  const [isGettingSuggestion, setIsGettingSuggestion] = useState(false);
  const [aiReasoning, setAiReasoning] = useState<string | null>(null);

  const { currentMonthKey, currentYear, data } = useMemo(() => {
    const today = new Date();
    const monthKey = today.toISOString().slice(0, 7); // "YYYY-MM"
    const year = today.getFullYear();

    // Monthly data calculation
    const monthlyBudget = budgets[monthKey];
    const currentMonthItems = items.filter(item => item.purchaseDate.startsWith(monthKey));
    const monthlySpend = currentMonthItems.reduce((sum, item) => sum + item.totalPrice, 0);
    const monthlyCategorySpending = CATEGORIES.map(cat => ({
        name: cat,
        spend: currentMonthItems.filter(i => i.category === cat).reduce((sum, i) => sum + i.totalPrice, 0),
        budget: monthlyBudget?.categories[cat] || 0
    })).filter(d => d.spend > 0 || d.budget > 0).sort((a,b) => b.spend - a.spend);

    // Annual data calculation
    const annualBudgetTotal = Object.entries(budgets)
        .filter(([key]) => key.startsWith(String(year)))
        .reduce((sum, [, budget]) => sum + budget.total, 0);
    const currentYearItems = items.filter(item => new Date(item.purchaseDate).getFullYear() === year);
    const annualSpend = currentYearItems.reduce((sum, item) => sum + item.totalPrice, 0);
    const annualCategorySpending = CATEGORIES.map(cat => {
        const totalBudgetForCat = Object.entries(budgets)
            .filter(([key]) => key.startsWith(String(year)))
            .reduce((sum, [, budget]) => sum + (budget.categories[cat] || 0), 0);
        
        return {
            name: cat,
            spend: currentYearItems.filter(i => i.category === cat).reduce((sum, i) => sum + i.totalPrice, 0),
            budget: totalBudgetForCat
        };
    }).filter(d => d.spend > 0 || d.budget > 0).sort((a,b) => b.spend - a.spend);

    const monthlyData = {
        title: `${new Date(monthKey + '-02').toLocaleString('default', { month: 'long', year: 'numeric' })} Budget`,
        budget: monthlyBudget,
        spent: monthlySpend,
        remaining: (monthlyBudget?.total || 0) - monthlySpend,
        progress: monthlyBudget?.total > 0 ? (monthlySpend / monthlyBudget.total) * 100 : 0,
        categorySpending: monthlyCategorySpending,
    };
    
    const annualData = {
        title: `${year} Annual Budget`,
        budget: { total: annualBudgetTotal, categories: {} }, // simplified for annual view
        spent: annualSpend,
        remaining: annualBudgetTotal - annualSpend,
        progress: annualBudgetTotal > 0 ? (annualSpend / annualBudgetTotal) * 100 : 0,
        categorySpending: annualCategorySpending,
    }

    return {
        currentMonthKey: monthKey,
        currentYear: year,
        data: viewMode === 'monthly' ? monthlyData : annualData
    };
  }, [items, budgets, viewMode]);
  
  useEffect(() => {
    if (viewMode === 'monthly' && data.budget) {
        setTotalBudgetInput(data.budget.total.toString());
        const cats = Object.fromEntries(
            Object.entries(data.budget.categories).map(([key, value]) => [key, value.toString()])
        );
        setCategoryBudgetsInput(cats);
        setAiReasoning(null);
    } else {
        setTotalBudgetInput('');
        setCategoryBudgetsInput({});
        setAiReasoning(null);
    }
  }, [data.budget, viewMode]);

  const handleSetBudget = () => {
    const total = parseFloat(totalBudgetInput);
    if (isNaN(total) || total < 0) return;

    const categories = Object.fromEntries(
        Object.entries(categoryBudgetsInput)
            // Fix: Explicitly setting the return type of map to `[string, number]` ensures
            // that `value` is correctly typed as a number for the subsequent filter operation.
            .map(([key, value]): [string, number] => [key, parseFloat(value as string)])
            .filter(([, value]) => !isNaN(value) && value > 0)
    );

    onUpdateBudget(currentMonthKey, { total, categories: categories as {[key in Category]?: number} });
  };
  
  const handleResetBudget = () => {
    onUpdateBudget(currentMonthKey, null);
    setShowCategoryBudgets(false);
  }

  const handleGetSuggestion = async () => {
    setIsGettingSuggestion(true);
    setAiReasoning(null);
    try {
        const recommendation = await getBudgetRecommendation(items);
        if (recommendation) {
            setTotalBudgetInput(recommendation.total.toString());
            const catInputs = Object.fromEntries(
                Object.entries(recommendation.categories).map(([key, value]) => [key, value?.toString() || ''])
            );
            setCategoryBudgetsInput(catInputs);
            setAiReasoning(recommendation.reasoning);
        } else {
            setAiReasoning("I couldn't generate a suggestion due to insufficient spending history.");
        }
    } catch (error) {
        console.error("Failed to get budget suggestion:", error);
        setAiReasoning("Sorry, I couldn't get a suggestion right now. Please try again.");
    } finally {
        setIsGettingSuggestion(false);
    }
  };

  const getProgressBarColor = () => {
    if (data.progress > 95) return 'bg-red-600';
    if (data.progress > 75) return 'bg-yellow-500';
    return 'bg-green-600';
  };
  
  const ViewToggle = () => (
    <div className="flex justify-center p-1 bg-gray-200 dark:bg-gray-700 rounded-lg">
        <button onClick={() => setViewMode('monthly')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors w-1/2 ${viewMode === 'monthly' ? 'bg-white dark:bg-gray-800 text-primary-600 dark:text-primary-400 shadow' : 'text-gray-600 dark:text-gray-300'}`}>Monthly</button>
        <button onClick={() => setViewMode('annual')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors w-1/2 ${viewMode === 'annual' ? 'bg-white dark:bg-gray-800 text-primary-600 dark:text-primary-400 shadow' : 'text-gray-600 dark:text-gray-300'}`}>Annual</button>
    </div>
  );

  return (
    <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Budget Tracker</h1>
                <p className="text-gray-600 dark:text-gray-400 mt-1">Manage your grocery budget and spending.</p>
            </div>
            <div className="w-full sm:w-64">
                <ViewToggle />
            </div>
        </div>
        
        <Card>
            <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4">
                {data.title}
            </h2>
            {data.budget?.total > 0 || viewMode === 'annual' ? (
                <div className="space-y-4">
                    <div className="w-full bg-gray-200 rounded-full h-4 dark:bg-gray-700">
                        <div 
                            className={`h-4 rounded-full transition-all duration-500 ${getProgressBarColor()}`}
                            style={{ width: `${Math.min(data.progress, 100)}%` }}
                        ></div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Budget</p>
                            <p className="text-2xl font-bold">{data.budget?.total.toFixed(2)} <span className="text-lg">GHS</span></p>
                        </div>
                         <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Spent</p>
                            <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">{data.spent.toFixed(2)} <span className="text-lg">GHS</span></p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Remaining</p>
                            <p className={`text-2xl font-bold ${data.remaining < 0 ? 'text-red-500' : 'text-green-500'}`}>
                                {data.remaining.toFixed(2)} <span className="text-lg">GHS</span>
                            </p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">% Spent</p>
                            <p className="text-2xl font-bold">{data.progress.toFixed(1)}%</p>
                        </div>
                    </div>
                     {viewMode === 'monthly' && <div className="flex justify-center pt-2 gap-2">
                        <Button variant="secondary" onClick={() => setShowCategoryBudgets(!showCategoryBudgets)}>
                            {showCategoryBudgets ? 'Hide' : 'Edit'} Category Budgets
                        </Button>
                        <Button variant="danger" onClick={handleResetBudget}>Reset Budget</Button>
                    </div>}
                </div>
            ) : ( // Only shows for monthly view if budget is not set
                <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg space-y-4">
                    <div className="flex flex-col sm:flex-row items-center gap-4">
                        <p className="text-gray-700 dark:text-gray-300 flex-grow text-center sm:text-left">Set your total budget for this month or get a smart suggestion.</p>
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                            <Button
                                variant="secondary"
                                onClick={handleGetSuggestion}
                                disabled={isGettingSuggestion}
                                className="w-full flex items-center justify-center gap-2"
                            >
                                {isGettingSuggestion ? <SpinnerIcon className="w-5 h-5"/> : <SparklesIcon className="w-5 h-5" />}
                                Get AI Suggestion
                            </Button>
                        </div>
                    </div>
                    
                    {aiReasoning && (
                        <div className="p-3 bg-primary-50 dark:bg-primary-900/30 border border-primary-200 dark:border-primary-800 rounded-lg text-sm text-primary-700 dark:text-primary-200">
                            <p><span className="font-semibold">Suggestion:</span> {aiReasoning}</p>
                        </div>
                    )}

                    <div className="flex items-center gap-2 w-full">
                        <input
                            type="number"
                            value={totalBudgetInput}
                            onChange={(e) => setTotalBudgetInput(e.target.value)}
                            placeholder="Enter budget or get a suggestion"
                            className="flex-grow px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                        />
                        <Button onClick={handleSetBudget} disabled={!totalBudgetInput}>Set Budget</Button>
                    </div>
                </div>
            )}
            {viewMode === 'monthly' && showCategoryBudgets && data.budget && (
                <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <h3 className="text-lg font-semibold mb-3">Category Budgets (Optional)</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {CATEGORIES.map(cat => (
                            <div key={cat}>
                                <label className="block text-sm font-medium text-gray-600 dark:text-gray-400">{cat}</label>
                                <input
                                    type="number"
                                    placeholder="0"
                                    value={categoryBudgetsInput[cat] || ''}
                                    onChange={e => setCategoryBudgetsInput(prev => ({ ...prev, [cat]: e.target.value }))}
                                    className="mt-1 w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 border border-transparent rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                                />
                            </div>
                        ))}
                    </div>
                    <div className="flex justify-end mt-4">
                        <Button onClick={handleSetBudget}>Save Budgets</Button>
                    </div>
                </div>
            )}
        </Card>

        <Card>
            <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4">Spending by Category</h2>
            {data.categorySpending.length > 0 ? (
                <div style={{ width: '100%', height: 300 }}>
                    <ResponsiveContainer>
                        <BarChart data={data.categorySpending} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                            <XAxis type="number" stroke="#9ca3af" fontSize={12} domain={[0, 'dataMax + 10']} hide />
                            <YAxis type="category" dataKey="name" stroke="#9ca3af" fontSize={12} width={100} tickLine={false} axisLine={false} />
                            <Tooltip
                                cursor={{ fill: 'rgba(128, 128, 128, 0.1)' }}
                                contentStyle={{
                                    backgroundColor: 'rgba(31, 41, 55, 0.9)',
                                    borderColor: '#4b5563',
                                    color: '#ffffff'
                                }}
                                formatter={(value: number, name: string, props: any) => {
                                    const { budget } = props.payload;
                                    if (budget > 0) {
                                        return [`${value.toFixed(2)} of ${budget.toFixed(2)} GHS`, "Spend"];
                                    }
                                    return [`${value.toFixed(2)} GHS`, "Spend"];
                                }}
                            />
                            <Bar dataKey="spend" radius={[0, 5, 5, 0]}>
                                {data.categorySpending.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.budget > 0 && entry.spend > entry.budget ? '#ef4444' : COLORS[index % COLORS.length]} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
             ) : (
                <p className="text-center text-gray-500 dark:text-gray-400 py-8">No spending recorded for this period yet.</p>
             )}
        </Card>
    </div>
  );
};