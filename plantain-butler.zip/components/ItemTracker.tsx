import React from 'react';
import { TrackedItem } from '../types';
import { ItemCard } from './ItemCard';

interface ItemTrackerProps {
    items: TrackedItem[];
}

export const ItemTracker: React.FC<ItemTrackerProps> = ({ items }) => {
    const sortedItems = [...items].sort((a, b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());

    return (
        <div>
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Tracked Items</h2>
            {sortedItems.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {sortedItems.map(item => (
                        <ItemCard key={item.id} item={item} />
                    ))}
                </div>
            ) : (
                <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg shadow-md">
                    <h3 className="text-xl font-semibold text-gray-700 dark:text-gray-200">Your inventory is empty!</h3>
                    <p className="mt-2 text-gray-500 dark:text-gray-400">Upload a receipt to start tracking your groceries.</p>
                </div>
            )}
        </div>
    );
};
