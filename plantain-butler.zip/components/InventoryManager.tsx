import React, { useState, useMemo } from 'react';
import { TrackedItem, Category } from '../types';
import { CATEGORIES } from '../constants';
import { Card } from './common/Card';
import { Button } from './common/Button';
import { PlusIcon } from './icons/PlusIcon';
import { TrashIcon } from './icons/TrashIcon';
import { UploadIcon } from './icons/UploadIcon';

type DurationUnit = 'Days' | 'Weeks' | 'Months';

interface InventoryManagerProps {
  inventory: TrackedItem[];
  onUpdateItem: (item: TrackedItem) => void;
  onDeleteItem: (itemId: string) => void;
  onOpenAddItemModal: (item: TrackedItem | null) => void;
  onOpenUploadModal: () => void;
}

export const InventoryManager: React.FC<InventoryManagerProps> = ({ inventory, onUpdateItem, onDeleteItem, onOpenAddItemModal, onOpenUploadModal }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<Category | 'all'>('all');
  
  const calculateFinishDate = (quantity: number, durationValue: number, durationUnit: DurationUnit): string => {
      const finishDate = new Date(); // Always calculate from today
      const q = Math.max(0, quantity);

      if (durationUnit === 'Days') {
          finishDate.setDate(finishDate.getDate() + durationValue * q);
      } else if (durationUnit === 'Weeks') {
          finishDate.setDate(finishDate.getDate() + durationValue * 7 * q);
      } else if (durationUnit === 'Months') {
          finishDate.setMonth(finishDate.getMonth() + durationValue * q);
      }
      return finishDate.toISOString();
  };

  const handleQuantityChange = (itemId: string, newQuantity: number) => {
    const itemToUpdate = inventory.find(i => i.id === itemId);
    if (itemToUpdate && newQuantity >= 0) {
        let itemDuration = itemToUpdate.durationPerUnit;
        let itemUnit = itemToUpdate.durationUnit;

        // Fallback for legacy items that don't have per-unit duration stored
        if (!itemDuration) {
            if (itemToUpdate.estimatedFinishDate && itemToUpdate.purchaseDate && itemToUpdate.initialQuantity > 0) {
                const purchaseD = new Date(itemToUpdate.purchaseDate);
                const finishD = new Date(itemToUpdate.estimatedFinishDate);
                const diffTime = finishD.getTime() - purchaseD.getTime();
                const totalDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                itemDuration = Math.max(1, Math.round(totalDays / itemToUpdate.initialQuantity));
                itemUnit = 'Days';
            } else {
                itemDuration = 1; // Absolute fallback
                itemUnit = 'Days';
            }
        }
        
        const newFinishDate = calculateFinishDate(newQuantity, itemDuration, itemUnit as DurationUnit);
        
        onUpdateItem({ 
          ...itemToUpdate, 
          quantity: newQuantity,
          totalPrice: newQuantity * itemToUpdate.unitPrice,
          estimatedFinishDate: newFinishDate
        });
    }
  };

  const filteredInventory = useMemo(() => {
    return inventory.filter(item => {
        const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = filterCategory === 'all' || item.category === filterCategory;
        return matchesSearch && matchesCategory;
    }).sort((a,b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());
  }, [inventory, searchTerm, filterCategory]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
              <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Inventory</h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">Manage all your grocery items in one place.</p>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
              <Button onClick={onOpenUploadModal} variant="secondary" className="w-1/2 sm:w-auto flex items-center gap-2">
                  <UploadIcon className="w-5 h-5" /> Upload File
              </Button>
              <Button onClick={() => onOpenAddItemModal(null)} className="w-1/2 sm:w-auto flex items-center gap-2">
                  <PlusIcon className="w-5 h-5" /> Add Manually
              </Button>
          </div>
      </div>
      
      <Card>
          <div className="flex flex-col sm:flex-row gap-4 mb-4">
              <input 
                  type="text" placeholder="Search items..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 border border-transparent rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
              <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value as Category | 'all')}
                  className="w-full sm:w-48 px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 border border-transparent rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                  <option value="all">All Categories</option>
                  {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
              </select>
          </div>

          <div className="overflow-x-auto">
              <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                  <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                      <tr>
                          <th scope="col" className="px-6 py-3">Item</th>
                          <th scope="col" className="px-6 py-3">Category</th>
                          <th scope="col" className="px-6 py-3">Quantity left</th>
                          <th scope="col" className="px-6 py-3 hidden md:table-cell">Will likely finish on</th>
                          <th scope="col" className="px-6 py-3 hidden sm:table-cell">Purchase Date</th>
                          <th scope="col" className="px-6 py-3">Price (GHS)</th>
                          <th scope="col" className="px-6 py-3"><span className="sr-only">Actions</span></th>
                      </tr>
                  </thead>
                  <tbody>
                      {filteredInventory.length > 0 ? (
                          filteredInventory.map(item => (
                              <tr key={item.id} className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                  <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">{item.name}</th>
                                  <td className="px-6 py-4">{item.category}</td>
                                  <td className="px-6 py-4">
                                      <div className="flex items-center gap-3">
                                          <button 
                                              onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                                              className="p-1 rounded-full bg-gray-200 dark:bg-gray-600 hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                              disabled={item.quantity <= 0}
                                              aria-label={`Decrease quantity of ${item.name}`}
                                          >
                                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                                  <path strokeLinecap="round" strokeLinejoin="round" d="M20 12H4" />
                                              </svg>
                                          </button>
                                          <span className="font-medium w-4 text-center">{item.quantity}</span>
                                          <button 
                                              onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                                              className="p-1 rounded-full bg-gray-200 dark:bg-gray-600 hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                                              aria-label={`Increase quantity of ${item.name}`}
                                          >
                                               <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                                              </svg>
                                          </button>
                                      </div>
                                  </td>
                                  <td className="px-6 py-4 hidden md:table-cell">{item.estimatedFinishDate ? new Date(item.estimatedFinishDate).toLocaleDateString() : 'N/A'}</td>
                                  <td className="px-6 py-4 hidden sm:table-cell">{new Date(item.purchaseDate).toLocaleDateString()}</td>
                                  <td className="px-6 py-4 font-medium">{item.totalPrice.toFixed(2)}</td>
                                  <td className="px-6 py-4 text-right">
                                      <div className="flex justify-end gap-4">
                                          <button onClick={() => onOpenAddItemModal(item)} className="font-medium text-primary-600 dark:text-primary-500 hover:underline">Edit</button>
                                          <button onClick={() => onDeleteItem(item.id)} className="font-medium text-red-600 dark:text-red-500 hover:underline"><TrashIcon className="w-5 h-5"/></button>
                                      </div>
                                  </td>
                              </tr>
                          ))
                      ) : (
                          <tr><td colSpan={7} className="text-center py-8">No items match your search.</td></tr>
                      )}
                  </tbody>
              </table>
          </div>
      </Card>
    </div>
  );
};