import React, { useState, useEffect } from 'react';
import { TrackedItem, Category } from '../types';
import { CATEGORIES } from '../constants';
import { Modal } from './common/Modal';
import { Button } from './common/Button';

const EMPTY_ITEM = { 
    name: '', 
    category: 'Produce' as Category, 
    quantity: 1, 
    initialQuantity: 1,
    lowStockThreshold: 1, 
    totalPrice: 0,
    unitPrice: 0
};

type DurationUnit = 'Days' | 'Weeks' | 'Months';

interface AddItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: Omit<TrackedItem, 'id'> | TrackedItem) => void;
  itemToEdit: Omit<TrackedItem, 'id'> | TrackedItem | null;
}

export const AddItemModal: React.FC<AddItemModalProps> = ({ isOpen, onClose, onSave, itemToEdit }) => {
  const [currentItem, setCurrentItem] = useState<Omit<TrackedItem, 'id'> | TrackedItem | null>(null);
  const [durationValue, setDurationValue] = useState(7);
  const [durationUnit, setDurationUnit] = useState<DurationUnit>('Days');

  useEffect(() => {
    if (isOpen) {
      const item = itemToEdit 
        ? { ...itemToEdit, purchaseDate: itemToEdit.purchaseDate || new Date().toISOString() } 
        : { ...EMPTY_ITEM, purchaseDate: new Date().toISOString() };
      setCurrentItem(item as TrackedItem | Omit<TrackedItem, 'id'>);

      if (itemToEdit && itemToEdit.durationPerUnit) {
          setDurationValue(itemToEdit.durationPerUnit);
          setDurationUnit(itemToEdit.durationUnit || 'Days');
      } else if (itemToEdit && itemToEdit.estimatedFinishDate && itemToEdit.purchaseDate && itemToEdit.initialQuantity > 0) {
          const purchaseD = new Date(itemToEdit.purchaseDate);
          const finishD = new Date(itemToEdit.estimatedFinishDate);
          const diffTime = finishD.getTime() - purchaseD.getTime();
          const totalDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          const perUnitDays = Math.max(1, Math.round(totalDays / itemToEdit.initialQuantity));
          setDurationValue(perUnitDays);
          setDurationUnit('Days');
      } else {
          setDurationValue(7);
          setDurationUnit('Days');
      }
    } else {
        setCurrentItem(null);
    }
  }, [isOpen, itemToEdit]);

  const calculateFinishDate = (quantity: number, durValue: number, durUnit: DurationUnit): string => {
      const finishDate = new Date(); // Always calculate from today
      const q = Math.max(0, quantity);

      if (durUnit === 'Days') {
          finishDate.setDate(finishDate.getDate() + durValue * q);
      } else if (durUnit === 'Weeks') {
          finishDate.setDate(finishDate.getDate() + durValue * 7 * q);
      } else if (durUnit === 'Months') {
          finishDate.setMonth(finishDate.getMonth() + durValue * q);
      }
      return finishDate.toISOString();
  };

  const handleSave = () => {
    if (currentItem && currentItem.name.trim()) {
      const finalQuantity = currentItem.quantity;
      const finalFinishDate = calculateFinishDate(finalQuantity, durationValue, durationUnit);
      
      const itemToSave = {
        ...currentItem,
        estimatedFinishDate: finalFinishDate,
        durationPerUnit: durationValue,
        durationUnit: durationUnit,
        initialQuantity: 'id' in currentItem ? currentItem.initialQuantity : finalQuantity,
      };
      onSave(itemToSave);
    }
  };

  const handleInputChange = (field: keyof Omit<TrackedItem, 'id'>, value: any) => {
    setCurrentItem(prev => {
        if (!prev) return null;
        
        let updatedItem: any = { ...prev, [field]: value };
        
        const newQuantity = field === 'quantity' ? parseInt(value) || 0 : updatedItem.quantity;
        const newUnitPrice = field === 'unitPrice' ? parseFloat(value) || 0 : updatedItem.unitPrice;
        const newTotalPrice = field === 'totalPrice' ? parseFloat(value) || 0 : updatedItem.totalPrice;

        if (field === 'quantity' || field === 'unitPrice') {
            updatedItem.totalPrice = newQuantity * newUnitPrice;
        } else if (field === 'totalPrice') {
            updatedItem.unitPrice = newQuantity > 0 ? newTotalPrice / newQuantity : 0;
        }
        
        return updatedItem;
    });
  };

  if (!isOpen || !currentItem) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={'id' in currentItem ? 'Edit Item' : 'Add New Item'}>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium">Item Name</label>
          <input type="text" value={currentItem.name} onChange={e => handleInputChange('name', e.target.value)} className="mt-1 block w-full input-style" />
        </div>
         <div>
          <label className="block text-sm font-medium">Category</label>
          <select value={currentItem.category} onChange={e => handleInputChange('category', e.target.value as Category)} className="mt-1 block w-full input-style">
            {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-4">
           <div>
            <label className="block text-sm font-medium">Quantity</label>
            <input type="number" value={currentItem.quantity} onChange={e => handleInputChange('quantity', parseInt(e.target.value) || 0)} min="0" className="mt-1 block w-full input-style" />
          </div>
          <div>
            <label className="block text-sm font-medium">Low Stock At</label>
            <input type="number" value={currentItem.lowStockThreshold} onChange={e => handleInputChange('lowStockThreshold', parseInt(e.target.value) || 0)} min="0" className="mt-1 block w-full input-style" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
            <div>
                <label className="block text-sm font-medium">Total Price (GHS)</label>
                <input type="number" value={currentItem.totalPrice} onChange={e => handleInputChange('totalPrice', parseFloat(e.target.value) || 0)} min="0" step="0.01" className="mt-1 block w-full input-style" />
            </div>
             <div>
                <label className="block text-sm font-medium">Unit Price (GHS)</label>
                <input type="number" value={currentItem.unitPrice} onChange={e => handleInputChange('unitPrice', parseFloat(e.target.value) || 0)} min="0" step="0.01" className="mt-1 block w-full input-style" />
            </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
             <div>
                <label className="block text-sm font-medium">Purchase Date</label>
                <input type="date" value={currentItem.purchaseDate.split('T')[0]} onChange={e => handleInputChange('purchaseDate', new Date(e.target.value).toISOString())} className="mt-1 block w-full input-style" max={new Date().toISOString().split('T')[0]} />
            </div>
            <div>
                <label className="block text-sm font-medium">Single Unit Lasts For</label>
                <div className="flex items-center mt-1">
                    <input 
                        type="number" 
                        value={durationValue}
                        onChange={e => setDurationValue(Math.max(1, parseInt(e.target.value) || 1))}
                        min="1"
                        className="w-1/2 rounded-l-md input-style"
                        aria-label="Duration value"
                    />
                    <select
                        value={durationUnit}
                        onChange={e => setDurationUnit(e.target.value as DurationUnit)}
                        className="w-1/2 rounded-r-md input-style border-l-0"
                        aria-label="Duration unit"
                    >
                        <option>Days</option>
                        <option>Weeks</option>
                        <option>Months</option>
                    </select>
                </div>
            </div>
        </div>
        <div className="flex justify-end gap-2 pt-4">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Save Item</Button>
        </div>
      </div>
       <style>{`.input-style { background-color: white; color: black; border: 1px solid #ccc; border-radius: 0.375rem; padding: 0.5rem 0.75rem; } .dark .input-style { background-color: #374151; color: white; border-color: #4b5563; }`}</style>
    </Modal>
  );
};