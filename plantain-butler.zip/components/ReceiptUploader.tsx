import React, { useState, useCallback } from 'react';
import { Card } from './common/Card';
import { Button } from './common/Button';
import { UploadIcon } from './icons/UploadIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { parseReceipt } from '../services/geminiService';

interface ReceiptUploaderProps {
  onReceiptParsed: (items: any[]) => void;
  setIsLoading: (isLoading: boolean) => void;
  isLoading: boolean;
  setError: (error: string | null) => void;
}

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = error => reject(error);
  });
};

export const ReceiptUploader: React.FC<ReceiptUploaderProps> = ({ onReceiptParsed, setIsLoading, isLoading, setError }) => {
  const [dragActive, setDragActive] = useState(false);

  const handleFile = useCallback(async (file: File) => {
    if (!file.type.startsWith('image/')) {
        setError('Please upload an image file.');
        return;
    }
    setError(null);
    setIsLoading(true);
    try {
        const base64Image = await fileToBase64(file);
        const newItems = await parseReceipt(base64Image, file.type);
        onReceiptParsed(newItems);
    } catch (e: any) {
        setError(e.message || 'An unknown error occurred.');
    } finally {
        setIsLoading(false);
    }
  }, [onReceiptParsed, setIsLoading, setError]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
        setDragActive(true);
    } else if (e.type === "dragleave") {
        setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        handleFile(e.dataTransfer.files[0]);
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
        handleFile(e.target.files[0]);
    }
  };

  return (
    <Card>
      <form onDragEnter={handleDrag} onSubmit={(e) => e.preventDefault()} className="relative text-center">
        <label htmlFor="receipt-upload" className={`flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${dragActive ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20' : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'}`}>
          {isLoading ? (
            <div className="flex flex-col items-center">
                <SpinnerIcon className="w-10 h-10 text-primary-500"/>
                <p className="mt-2 text-sm font-semibold text-gray-700 dark:text-gray-300">Analyzing Receipt...</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">This can take a moment.</p>
            </div>
          ) : (
            <>
              <UploadIcon className="w-10 h-10 text-gray-500 dark:text-gray-400 mb-2"/>
              <p className="mb-2 text-sm text-gray-600 dark:text-gray-300"><span className="font-semibold">Click to upload</span> or drag and drop</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">PNG, JPG, or WEBP</p>
            </>
          )}
        </label>
        <input id="receipt-upload" type="file" className="hidden" accept="image/*" onChange={handleChange} disabled={isLoading} />
        {dragActive && <div className="absolute inset-0 w-full h-full" onDragEnter={handleDrag} onDragLeave={handleDrag} onDragOver={handleDrag} onDrop={handleDrop}></div>}
      </form>
    </Card>
  );
};
