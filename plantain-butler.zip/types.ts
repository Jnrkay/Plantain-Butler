export type Category = 
  | 'Produce'
  | 'Dairy & Eggs'
  | 'Meat & Seafood'
  | 'Pantry'
  | 'Frozen'
  | 'Bakery'
  | 'Beverages'
  | 'Snacks'
  | 'Household'
  | 'Personal Care'
  | 'Other';

export interface TrackedItem {
  id: string;
  name: string;
  category: Category;
  quantity: number;
  initialQuantity: number; // The quantity when the item was purchased.
  unitPrice: number;
  totalPrice: number;
  purchaseDate: string; // ISO string
  estimatedFinishDate?: string; // ISO string
  lowStockThreshold: number;
  notes?: string;
  isSample?: boolean;
  durationPerUnit?: number; // How long a single unit lasts (e.g., 7)
  durationUnit?: 'Days' | 'Weeks' | 'Months'; // The unit for durationPerUnit
}

export interface ChatMessage {
    role: 'user' | 'model';
    text: string;
}

export type MonthlyBudget = {
  total: number;
  categories: {
    [key in Category]?: number;
  };
};

export type Budget = {
  [monthKey: string]: MonthlyBudget; // e.g. "2024-07": { total: 500, categories: { 'Snacks': 50 } }
};

export interface BudgetRecommendation {
  total: number;
  categories: {
    [key in Category]?: number;
  };
  reasoning: string;
}